//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    openid:'等待获取',
    session_key:'等待获取',
    orderNo:'',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  payForXPT:function(){
    var that=this;
    if (that.data.openid =="等待获取"){
      wx.showToast({
        title: '请先获取openid',
      })
      return;
    }
    wx.showModal({
      title: '提示',
      content: '确定支付吗',
      success(res) {
        if (res.confirm) {
          //调用鑫平台接口创建订单，返回订单号，并调起小程序支付窗口完成支付
          wx.request({
            url: 'http://xpt.ngrok.5fanqie.com/order/orderInfo',
            method:'put',
            data: {
              openId:that.data.openid,
              //openId:'oCIU_5YYZqBc4B32rXfvS5rIY-_I',
              //固定
              tradeType: 'JSAPI',
              //业务类型，0任务订单，1广告订单
              businessType:0,
              //订单金额
              orderAmount:0.01,
              //收支类型，0支出，1收入
              balanceType:0,
              //订单归属人id
              personId:1,
              //订单归属人类型，0经纪人，1普通用户
              personType:0,
              personName:'订单归属人姓名',
              //订单归属人电话
              personPhone:'13559489067',
              //发起支付的平台标识，4标识鑫平台小程序
              platForm:4
            },
            success: function (result) {
              var response=result.data;
              console.log(response);
              if(response.code!=0){
                 wx.showToast({
                  title: '下单失败，'+response.msg,
                  icon: 'success',
                  duration: 2000
                });
              }else{
                var orderNo=response.data.orderNo;
                console.log("订单号："+orderNo);
                //把订单号保存起来，用于查询支付状态
                that.data.orderNo=orderNo;
                var payInfoMap=response.data.payInfoMap;
                console.log("调起支付相关参数");
                console.log(payInfoMap);
                //调起小程序支付
                wx.requestPayment(
                  {
                    'timeStamp': payInfoMap.timeStamp,
                    'nonceStr': payInfoMap.nonceStr,
                    'package': payInfoMap.packageValue,
                    'signType': payInfoMap.signType,
                    'paySign': payInfoMap.paySign,
                    'success': function (res)
                     { 
                       //回调成功可以做个提醒支付成功，真正判断订单是否支付存在，还是要根据订单号轮询后台提供接口查询
                       console.log('success');
                       //res={errMsg:"requestPayment:ok"}
                       console.log(res);
                       setTimeout(function(){
                         wx.reLaunch({
                           url: '/pages/successfull/paysuccessfull',
                         })
                       },200);
                     },
                    'fail': function (res)
                     { 
                      console.log('fail');
                      console.log(res);
                    },
                    'complete': function (res) 
                    {
                      console.log('complete');
                      console.log(res);
                    }
                  });
              }           
          
             
            }
          })          

        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  //询问订单的支付状态
  askOrderStatus:function(){
    var that=this;
    if(that.data.orderNo==''){
      wx.showToast({
        title: '请先支付',
      })
      return;
    }
    wx.request({
      url: 'http://xpt.ngrok.5fanqie.com/order/orderInfo/getPayStatus',
      method: 'get',
      data:{
        orderNo: that.data.orderNo
      },
      success:function(res){
        console.log("获取支付状态");
        console.log(res.data);
        if(res.data.code==0){
          if(res.data.status==1){
            wx.showToast({
              title: '订单已支付',
            })
          }else{
            wx.showToast({
              title: '订单未支付',
            })
          }

        }else{
          console.log("获取订单状态服务接口失败");
        }
      }
    })
  },
  loginForOpenId:function(){
    var that=this;
    wx.login({
      success(res) {
        if (res.code) {
          //调用微信接口获取openId和session_key
          wx.request({
            url: 'http://wlhweixin.ngrok.5fanqie.com/uniapp/user/xptUniApp/auth/code2Session',
            data: {
              code: res.code
            },
            success: function (result) {
              var response=result.data;
              console.log(response);
              wx.showToast({
                title: '获取成功',
                icon: 'success',
                duration: 2000
              });
              console.log('小程序获取成功openid:', response.data.openid);
              console.log('session_key:', response.data.session_key);
              that.setData({ openid: response.data.openid });   
              that.setData({ session_key: response.data.session_key });   
            }
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
  },
  //事件处理函数
  bindViewTap: function() {   
    this.setData({ motto: "王龙海" });    
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
